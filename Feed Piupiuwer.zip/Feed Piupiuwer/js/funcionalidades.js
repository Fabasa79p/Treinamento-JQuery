//Aqui estará todo o conteúdo JavaScript que cuidará de promover todas as funcionalidades que serão permitidas no Piupiwer.

//Função responsável por excluir um post do feed. Ela é permitida somente para posts realizados pelo próprio usuário.

function RemovePost(){
    event.preventDefault();
    var post = $(this).parent().parent();
    post.fadeOut(1000);
    setTimeout(function() {
        post.remove();
    }, 1000);
}

//Função responsável por permitir que o usuário deixe um Like em algum post. 

function DaLike(){
    event.preventDefault();
    var bute = $(this);
    bute.addClass("deuLike");
    var numero = $(this).parent().parent().find(".numero_de_likes");
    numero.text("1");
}

//Função responsável por marcar um post do feed, fazendo com que ele "suba" no feed. Ela é permitida somente para posts de outros usuários (servidor).

function MarcaPost(){
    event.preventDefault();
    $('html,body').animate({scrollTop:$(this.hash).offset().top}, 1000);
    var adiciona = $(this).parent().parent();
    $(".posts").prepend(adiciona);
    var marcou = $(this).find(".alfinete");
    marcou.attr("src", "Imagens/estrela.png");
}
