//Aqui estará todo o conteúdo JavaScript que cuidará de adicionar os posts do servidor ao feed.

var campo = $("#piado");
atualizaPosts();

//Função responsável por adicionar todos os posts do servidor ao feed (adicionando uma foto anônima para usuários sem foto).

function atualizaPosts(){
    $.get("http://www.json-generator.com/api/json/get/ceycmRLqWa?indent=2",function(data){
        $(data).each(function(){
            if (this.imagem == ""){
                this.imagem = "Imagens/unknown.png";
            }
            var post = novoPost(this.nome, this.imagem, this.mensagem);
            
            post.find(".de_like").click(DaLike);
            post.find(".sobe").click(MarcaPost)
            var divContainer = $('.posts');
            divContainer.append(post);
        });
    });
}

//Função responsável por criar o HTML do post em si.

function novoPost(usuario,foto, post){
    var corpo = $("<div>").addClass("wrap");
    var container = $("<div>").addClass("container3");
    var marca = $("<a>").addClass("sobe").addClass("scroll").attr("href", "#piado");
    var marc = $("<img>").addClass("icones").addClass("alfinete").attr("src", "Imagens/marca.png");
    var caixa1 = $("<div>").addClass("caixa1");
    var formulario = $("<ul>");
    var item = $("<li>").addClass("personagem");
    var a1 = $("<a>").attr("href","#");
    var imagem = $("<img>").addClass("perfil").attr("src",foto);
    var item2 = $("<li>").addClass("personagem").addClass("nome");
    var a2 = $("<a>").attr("href","#");
    var nome = $("<strong>").text(usuario);
    var caixa2 =  $("<div>").addClass("caixa2");
    var texto = $("<p>").addClass("post").text(post);
    var caixa3 = $("<div>").addClass("caixa3");
    var ul = $("<ul>");
    var numero_de_likes = $("<li>").addClass("numeros numero_de_likes").text("0");
    var li_like = $("<li>").addClass("numeros").addClass("likes");
    var like = $("<img>").addClass("like").attr("src", "Imagens/Like.png");
    var libotao = $("<li>").addClass("numeros").addClass("button");
    var botao = $("<a>").addClass("botao").addClass("de_like").attr("href", "#").text("Curtir");
    var li_desenho = $("<li>").addClass("numeros").addClass("gost");
    var desenho = $("<img>").addClass("gostei").attr("src", "Imagens/curti.png");
    var div = $("<div>").addClass("div");

    marca.append(marc);
    container.append(marca);
    a1.append(imagem);
    item.append(a1);
    formulario.append(item);
    a2.append(nome);
    item2.append(a2);
    caixa1.append(item);
    caixa1.append(item2);
    caixa2.append(texto);
    container.append(caixa1);
    container.append(caixa2);
    li_desenho.append(desenho);
    libotao.append(botao);
    li_like.append(like);
    ul.append(numero_de_likes);
    ul.append(li_like);
    ul.append(libotao);
    ul.append(li_desenho);
    caixa3.append(ul);
    container.append(caixa3);
    corpo.append(container);
    corpo.append(div);

    return corpo;
}


