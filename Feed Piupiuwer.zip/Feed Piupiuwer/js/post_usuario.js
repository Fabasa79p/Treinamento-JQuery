//Aqui estará todo o conteúdo JavaScript que cuidará do post realizado pelo usuário (Piu).

var campo = $("#piado");

$(function(){
    contaLetras();
    $(".botao2").click(Piado);
})

//Função responsável por contar letras e bloquear o campo de digitação caso o usuário exceda 140 caracteres.


function contaLetras(){
    campo.on("input",function() {
        var conteudo = campo.val();
        var qtdCaracteres = conteudo.length;
        if (qtdCaracteres > 140){
            campo.attr("disabled", true);
            campo.toggleClass("campo-desativado");
            $("#erro").toggle();
        }
        else{
            campo.attr("disabled", false);
        }
    });
}

//Função responsável por adicionar o piado ao conjunto de posts do feed.


function Piado(){
    event.preventDefault();
    if(campo.val() != ""){
        var conteudo = campo.val();
        var post = CriaPost(conteudo);
        var divContainer = $('.posts');
        post.find(".de_like").click(DaLike);
        post.find(".remover").click(RemovePost);
        divContainer.prepend(post);
        campo.val("");
    }
}

//Função responsável por criar o HTML do post em si.

function CriaPost(conteudo){
    var corpo = $("<div>").addClass("wrap");
    var container = $("<div>").addClass("container3");
    var marca = $("<a>").addClass("remover").addClass("scroll").attr("href", "#piado");
    var marc = $("<img>").addClass("icones").addClass("alfinete").attr("src", "Imagens/lixo.png");
    var caixa1 = $("<div>").addClass("caixa1");
    var formulario = $("<ul>");
    var item = $("<li>").addClass("personagem");
    var a1 = $("<a>").attr("href","#");
    var imagem = $("<img>").addClass("perfil").attr("src","Imagens/unknown.png");
    var item2 = $("<li>").addClass("personagem").addClass("nome");
    var a2 = $("<a>").attr("href","#");
    var nome = $("<strong>").text("Fábio Bassoi Sayeg");
    var caixa2 =  $("<div>").addClass("caixa2");
    var texto = $("<p>").addClass("post").text(conteudo);
    var caixa3 = $("<div>").addClass("caixa3");
    var ul = $("<ul>");
    var numero_de_likes = $("<li>").addClass("numeros numero_de_likes").text("0");
    var li_like = $("<li>").addClass("numeros").addClass("likes");
    var like = $("<img>").addClass("like").attr("src", "Imagens/Like.png");
    var libotao = $("<li>").addClass("numeros").addClass("button");
    var botao = $("<a>").addClass("botao").addClass("de_like").attr("href", "#").text("Curtir");
    var li_desenho = $("<li>").addClass("numeros").addClass("gost");
    var desenho = $("<img>").addClass("gostei").attr("src", "Imagens/curti.png");
    var div = $("<div>").addClass("div");

    marca.append(marc);
    container.append(marca);
    a1.append(imagem);
    item.append(a1);
    formulario.append(item);
    a2.append(nome);
    item2.append(a2);
    caixa1.append(item);
    caixa1.append(item2);
    caixa2.append(texto);
    container.append(caixa1);
    container.append(caixa2);
    li_desenho.append(desenho);
    libotao.append(botao);
    li_like.append(like);
    ul.append(numero_de_likes);
    ul.append(li_like);
    ul.append(libotao);
    ul.append(li_desenho);
    caixa3.append(ul);
    container.append(caixa3);
    corpo.append(container);
    corpo.append(div);

    return corpo;
}

